package dev.hudclient.util;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Finds blocks by id string without caring about the registry accessor names. */
public final class BlockIds {
    private static Map<String, Block> map;

    private BlockIds() {
    }

    private static Map<String, Block> map() {
        if (map == null) {
            Map<String, Block> m = new HashMap<>();
            for (Block b : BuiltInRegistries.BLOCK) {
                m.put(String.valueOf(BuiltInRegistries.BLOCK.getKey(b)), b);
            }
            map = m;
        }
        return map;
    }

    public static String normalize(String s) {
        String t = s.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        return t.contains(":") ? t : "minecraft:" + t;
    }

    public static Block find(String s) {
        return map().get(normalize(s));
    }
}
