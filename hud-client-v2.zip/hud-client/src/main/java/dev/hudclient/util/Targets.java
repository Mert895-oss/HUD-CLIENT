package dev.hudclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class Targets {
    private Targets() {
    }

    public static boolean valid(LocalPlayer self, Entity e, boolean players, boolean mobs) {
        if (e == null || e == self) {
            return false;
        }
        if (!(e instanceof LivingEntity)) {
            return false;
        }
        if (!((LivingEntity) e).isAlive()) {
            return false;
        }
        if (e instanceof Player) {
            return players && !e.isSpectator();
        }
        return mobs && e instanceof Mob;
    }

    public static LivingEntity nearest(Minecraft mc, double range, boolean players, boolean mobs) {
        LocalPlayer self = mc.player;
        ClientLevel level = mc.level;
        if (self == null || level == null) {
            return null;
        }
        Vec3 eye = self.getEyePosition();
        LivingEntity best = null;
        double bestDist = range * range;
        for (Entity e : level.entitiesForRendering()) {
            if (!valid(self, e, players, mobs)) {
                continue;
            }
            double d = e.getBoundingBox().distanceToSqr(eye);
            if (d < bestDist) {
                bestDist = d;
                best = (LivingEntity) e;
            }
        }
        return best;
    }

    /** Returns {yaw, pitch} needed to look from eye to target. */
    public static float[] rotationTo(Vec3 eye, Vec3 target) {
        double dx = target.x - eye.x;
        double dy = target.y - eye.y;
        double dz = target.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));
        return new float[]{yaw, pitch};
    }
}
