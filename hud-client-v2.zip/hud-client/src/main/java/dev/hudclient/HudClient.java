package dev.hudclient;

import dev.hudclient.command.Commands;
import dev.hudclient.config.Config;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.module.misc.NameProtect;
import dev.hudclient.render.Render3D;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HudClient implements ClientModInitializer {
    public static final String MOD_ID = "hud";
    public static final String NAME = "HUD";
    public static final String VERSION = "v2";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Config.load();

        ClientTickEvents.START_CLIENT_TICK.register(ModuleManager::tick);

        WorldRenderEvents.BEFORE_TRANSLUCENT.register(context -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null || mc.player == null) {
                return;
            }
            Render3D.begin(context);
            ModuleManager.render3D();
            Render3D.end();
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "overlay"),
                (graphics, deltaTracker) -> ModuleManager.renderHud(graphics)
        );

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> Commands.register(dispatcher));

        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signed, sender, params, timestamp) -> NameProtect.onChat(message));
        ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> overlay ? message : NameProtect.modify(message));

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            Config.save();
            Render3D.close();
        });

        LOGGER.info("{} {} loaded", NAME, VERSION);
    }
}
