package dev.hudclient.module.chunk;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.player.LocalPlayer;

import java.util.Collection;

/** Base for modules that mark 16x16 chunks. Chunks are int[]{chunkX, chunkZ}. */
public abstract class ChunkMarker extends Module {
    protected final ColorSetting color;
    protected final NumberSetting alpha = num("Line Alpha", 230, 0, 255, 1);
    protected final NumberSetting width = num("Line Width", 0.08, 0.01, 0.5, 0.01);
    protected final BoolSetting fill = bool("Fill Plate", true);
    protected final NumberSetting fillAlpha = num("Fill Alpha", 50, 0, 255, 1);
    protected final NumberSetting yOffset = num("Y Offset", 0, -64, 64, 1);
    protected final BoolSetting pillars = bool("Corner Pillars", true);
    protected final NumberSetting pillarHeight = num("Pillar Height", 24, 2, 128, 2);

    protected ChunkMarker(String name, int r, int g, int b) {
        super(name, Category.CHUNKS);
        this.color = color("Color", r, g, b);
    }

    protected abstract Collection<int[]> chunks();

    @Override
    public void onRender3D() {
        LocalPlayer p = mc.player;
        if (p == null) {
            return;
        }
        double y = Math.floor(p.getY()) + yOffset.getD();
        int lineColor = color.argb(alpha.getInt());
        int fillColor = color.argb(fillAlpha.getInt());
        double w = width.getD();
        double ph = pillarHeight.getD();

        for (int[] c : chunks()) {
            double x0 = c[0] * 16.0;
            double z0 = c[1] * 16.0;
            double x1 = x0 + 16.0;
            double z1 = z0 + 16.0;

            if (fill.get()) {
                Render3D.box(x0, y, z0, x1, y + 0.02, z1, fillColor);
            }
            Render3D.line(x0, y, z0, x1, y, z0, w, lineColor);
            Render3D.line(x1, y, z0, x1, y, z1, w, lineColor);
            Render3D.line(x1, y, z1, x0, y, z1, w, lineColor);
            Render3D.line(x0, y, z1, x0, y, z0, w, lineColor);

            if (pillars.get()) {
                Render3D.line(x0, y - ph, z0, x0, y + ph, z0, w, lineColor);
                Render3D.line(x1, y - ph, z0, x1, y + ph, z0, w, lineColor);
                Render3D.line(x1, y - ph, z1, x1, y + ph, z1, w, lineColor);
                Render3D.line(x0, y - ph, z1, x0, y + ph, z1, w, lineColor);
            }
        }
    }
}
