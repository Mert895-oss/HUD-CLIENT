package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.util.Targets;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

public class AimAssist extends Module {
    private final NumberSetting range = num("Range", 5.0, 2.0, 8.0, 0.5);
    private final NumberSetting fov = num("FOV", 90.0, 10.0, 360.0, 5.0);
    private final NumberSetting smooth = num("Smoothness", 6.0, 1.0, 20.0, 1.0);
    private final BoolSetting mobs = bool("Mobs", false);
    private final BoolSetting onlyAttacking = bool("Only While Attacking", true);

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.screen != null) {
            return;
        }
        if (onlyAttacking.get() && !mc.options.keyAttack.isDown()) {
            return;
        }
        LivingEntity target = Targets.nearest(mc, range.getD(), true, mobs.get());
        if (target == null) {
            return;
        }
        float[] rot = Targets.rotationTo(p.getEyePosition(), target.getBoundingBox().getCenter());
        float dyaw = Mth.wrapDegrees(rot[0] - p.getYRot());
        float dpitch = rot[1] - p.getXRot();
        if (Math.abs(dyaw) > fov.getD() / 2.0) {
            return;
        }
        float s = (float) smooth.getD();
        p.setYRot(p.getYRot() + dyaw / s);
        p.setXRot(Math.max(-90.0f, Math.min(90.0f, p.getXRot() + dpitch / s)));
    }
}
