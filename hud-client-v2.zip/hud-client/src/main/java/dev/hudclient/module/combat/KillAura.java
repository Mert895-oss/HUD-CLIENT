package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.util.Targets;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;

public class KillAura extends Module {
    private final NumberSetting range = num("Range", 4.2, 2.0, 6.0, 0.1);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", false);
    private final BoolSetting rotate = bool("Rotate", true);
    private final BoolSetting cooldown = bool("Wait Cooldown", true);

    public KillAura() {
        super("KillAura", Category.COMBAT);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null) {
            return;
        }
        LivingEntity target = Targets.nearest(mc, range.getD(), players.get(), mobs.get());
        if (target == null) {
            return;
        }
        if (rotate.get()) {
            float[] rot = Targets.rotationTo(p.getEyePosition(), target.getBoundingBox().getCenter());
            p.setYRot(rot[0]);
            p.setXRot(rot[1]);
        }
        if (cooldown.get() && p.getAttackStrengthScale(0.5f) < 1.0f) {
            return;
        }
        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
