package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Shows ancient debris (netherite source) in the Nether: boxes, tracers and chat coordinates. */
public class NetheriteFinder extends BlockFinder {
    private final BoolSetting exposedOnly;
    private final NumberSetting minY;
    private final NumberSetting maxY;

    public NetheriteFinder() {
        super("NetheriteFinder+", Category.RENDER, 255, 140, 0);
        exposedOnly = bool("Exposed Only", false);
        minY = num("Min Y", 0, 0, 128, 1);
        maxY = num("Max Y", 128, 0, 128, 1);
    }

    @Override
    protected boolean active() {
        return mc.level != null && mc.level.dimension() == Level.NETHER;
    }

    @Override
    protected boolean isTarget(BlockState state) {
        return state.is(Blocks.ANCIENT_DEBRIS);
    }

    @Override
    protected boolean accept(ClientLevel level, BlockPos pos) {
        if (pos.getY() < minY.getInt() || pos.getY() > maxY.getInt()) {
            return false;
        }
        if (!exposedOnly.get()) {
            return true;
        }
        for (Direction d : Direction.values()) {
            if (level.getBlockState(pos.relative(d)).isAir()) {
                return true;
            }
        }
        return false;
    }

    @Override
    protected String label(BlockState state) {
        return "Ancient Debris";
    }
}
