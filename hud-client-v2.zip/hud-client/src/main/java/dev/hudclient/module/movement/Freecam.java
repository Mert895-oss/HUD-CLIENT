package dev.hudclient.module.movement;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.util.CameraControl;
import org.lwjgl.glfw.GLFW;

/** Fly the camera around while your character stays where it is. WASD + Space/Shift (default keys). */
public class Freecam extends Module {
    private final NumberSetting speed = num("Speed", 1.0, 0.1, 5.0, 0.1);

    public Freecam() {
        super("Freecam", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        if (mc.player == null) {
            setEnabled(false);
            return;
        }
        CameraControl.start(mc, true);
    }

    @Override
    public void onDisable() {
        CameraControl.stop(mc, true);
    }

    private static boolean down(long window, int key) {
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
    }

    @Override
    public void onTick() {
        CameraControl.px = CameraControl.x;
        CameraControl.py = CameraControl.y;
        CameraControl.pz = CameraControl.z;
        if (mc.screen != null) {
            return;
        }
        long w = GLFW.glfwGetCurrentContext();
        boolean fw = down(w, GLFW.GLFW_KEY_W);
        boolean back = down(w, GLFW.GLFW_KEY_S);
        boolean left = down(w, GLFW.GLFW_KEY_A);
        boolean right = down(w, GLFW.GLFW_KEY_D);
        boolean up = down(w, GLFW.GLFW_KEY_SPACE);
        boolean dn = down(w, GLFW.GLFW_KEY_LEFT_SHIFT);

        double yr = Math.toRadians(CameraControl.yaw);
        double xr = Math.toRadians(CameraControl.pitch);
        double fx = -Math.sin(yr) * Math.cos(xr);
        double fy = -Math.sin(xr);
        double fz = Math.cos(yr) * Math.cos(xr);
        double rx = -Math.cos(yr);
        double rz = -Math.sin(yr);

        double mx = 0.0;
        double my = 0.0;
        double mz = 0.0;
        if (fw) {
            mx += fx;
            my += fy;
            mz += fz;
        }
        if (back) {
            mx -= fx;
            my -= fy;
            mz -= fz;
        }
        if (right) {
            mx += rx;
            mz += rz;
        }
        if (left) {
            mx -= rx;
            mz -= rz;
        }
        if (up) {
            my += 1.0;
        }
        if (dn) {
            my -= 1.0;
        }
        double len = Math.sqrt(mx * mx + my * my + mz * mz);
        if (len > 1.0E-6) {
            double s = speed.getD() * 0.6 / len;
            CameraControl.x += mx * s;
            CameraControl.y += my * s;
            CameraControl.z += mz * s;
        }

        // keep the real player still
        mc.options.keyUp.setDown(false);
        mc.options.keyDown.setDown(false);
        mc.options.keyLeft.setDown(false);
        mc.options.keyRight.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keyShift.setDown(false);
        mc.options.keySprint.setDown(false);
    }
}
