package dev.hudclient.module;

import dev.hudclient.setting.BlockListSetting;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.ListSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.setting.Setting;
import dev.hudclient.setting.TextSetting;
import dev.hudclient.setting.StringSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected final Minecraft mc = Minecraft.getInstance();

    public final Category category;
    private final String name;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private int key = -1;
    /** Used by ModuleManager for key edge detection. */
    boolean keyWasDown;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean value) {
        if (value == enabled) {
            return;
        }
        enabled = value;
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public List<Setting<?>> getSettings() {
        return settings;
    }

    protected BoolSetting bool(String settingName, boolean def) {
        BoolSetting s = new BoolSetting(settingName, def);
        settings.add(s);
        return s;
    }

    protected NumberSetting num(String settingName, double def, double min, double max, double step) {
        NumberSetting s = new NumberSetting(settingName, def, min, max, step);
        settings.add(s);
        return s;
    }

    protected ModeSetting mode(String settingName, String def, String... modes) {
        ModeSetting s = new ModeSetting(settingName, def, modes);
        settings.add(s);
        return s;
    }

    protected ColorSetting color(String settingName, int r, int g, int b) {
        ColorSetting c = new ColorSetting(settingName, r, g, b);
        settings.add(c.r);
        settings.add(c.g);
        settings.add(c.b);
        return c;
    }

    protected StringSetting string(String settingName, String def) {
        StringSetting s = new StringSetting(settingName, def);
        settings.add(s);
        return s;
    }

    protected BlockListSetting blockList(String settingName) {
        BlockListSetting s = new BlockListSetting(settingName);
        settings.add(s);
        return s;
    }

    /** Whether "enabled" is remembered between game launches. */
    public boolean persistEnabled() {
        return true;
    }

    /** Short help text shown at the bottom of the settings panel. */
    public String getHint() {
        return "";
    }

    protected TextSetting text(String settingName, String def) {
        TextSetting s = new TextSetting(settingName, def);
        settings.add(s);
        return s;
    }

    protected ListSetting list(String settingName, java.util.List<String> def) {
        ListSetting s = new ListSetting(settingName, def);
        settings.add(s);
        return s;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    /** Called at the start of every client tick while enabled (in game only). */
    public void onTick() {
    }

    /** Called every frame while enabled; draw with Render3D. */
    public void onRender3D() {
    }

    /** Called every frame while enabled; draw the 2D overlay. */
    public void onRenderHud(GuiGraphics graphics) {
    }
}
