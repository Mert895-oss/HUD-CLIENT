package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.setting.ListSetting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

/** Highlights blocks you choose. Manage the list with /blockesp add|remove|list|clear. */
public class BlockEsp extends BlockFinder {
    private final ListSetting blocks;
    private final Set<Block> targets = new HashSet<>();
    private int seenVersion = -1;

    public BlockEsp() {
        super("BlockESP", Category.RENDER, 80, 255, 120);
        blocks = list("Blocks (/blockesp)", List.of("minecraft:diamond_ore", "minecraft:deepslate_diamond_ore"));
    }

    private void refresh() {
        if (seenVersion == blocks.version) {
            return;
        }
        seenVersion = blocks.version;
        targets.clear();
        for (String s : blocks.get()) {
            Identifier id = Identifier.tryParse(s);
            if (id == null) {
                continue;
            }
            Optional<Block> b = BuiltInRegistries.BLOCK.getOptional(id);
            b.ifPresent(targets::add);
        }
        rescan();
    }

    @Override
    public void onTick() {
        refresh();
        super.onTick();
    }

    @Override
    protected boolean isTarget(BlockState state) {
        return targets.contains(state.getBlock());
    }

    // ---- used by the /blockesp command

    public String addBlock(String raw) {
        String text = raw.contains(":") ? raw : "minecraft:" + raw;
        Identifier id = Identifier.tryParse(text.toLowerCase(Locale.ROOT));
        if (id == null) {
            return "Gecersiz isim: " + raw;
        }
        if (BuiltInRegistries.BLOCK.getOptional(id).isEmpty()) {
            return "Blok bulunamadi: " + id;
        }
        return blocks.add(id.toString()) ? "Eklendi: " + id : "Zaten listede: " + id;
    }

    public String removeBlock(String raw) {
        String text = raw.contains(":") ? raw : "minecraft:" + raw;
        return blocks.remove(text.toLowerCase(Locale.ROOT)) ? "Silindi: " + text : "Listede yok: " + text;
    }

    public String clearBlocks() {
        blocks.clear();
        return "Liste temizlendi";
    }

    public String listBlocks() {
        return blocks.get().isEmpty() ? "Liste bos" : "Bloklar: " + String.join(", ", blocks.get());
    }
}
