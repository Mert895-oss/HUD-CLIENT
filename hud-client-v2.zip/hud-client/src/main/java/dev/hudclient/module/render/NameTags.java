package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.misc.NameProtect;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.util.CameraControl;
import dev.hudclient.util.Projection;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;

import java.util.Locale;

/** Draws a name tag (name, health, distance) over every player, readable through walls. */
public class NameTags extends Module {
    private final BoolSetting health = bool("Show Health", true);
    private final BoolSetting distance = bool("Show Distance", true);
    private final BoolSetting self = bool("Show Self", false);
    private final NumberSetting range = num("Range", 128, 16, 512, 8);
    private final NumberSetting bgAlpha = num("Background Alpha", 120, 0, 255, 1);
    private final ColorSetting color = color("Color", 255, 255, 255);

    public NameTags() {
        super("NameTags", Category.RENDER);
    }

    @Override
    public void onRenderHud(GuiGraphics g) {
        if (mc.level == null || mc.player == null) {
            return;
        }
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        int textColor = 0xFF000000 | color.rgb();
        for (AbstractClientPlayer e : mc.level.players()) {
            boolean isSelf = e == mc.player;
            if (isSelf && !(self.get() || CameraControl.freecam)) {
                continue;
            }
            if (e.isSpectator()) {
                continue;
            }
            double dist = Math.sqrt(mc.player.distanceToSqr(e));
            if (!isSelf && dist > range.getD()) {
                continue;
            }
            double x = Mth.lerp(pt, e.xo, e.getX());
            double y = Mth.lerp(pt, e.yo, e.getY()) + e.getBbHeight() + 0.45;
            double z = Mth.lerp(pt, e.zo, e.getZ());
            double[] s = Projection.toScreen(x, y, z);
            if (s == null) {
                continue;
            }

            String text = NameProtect.apply(e.getName().getString());
            int hpColor = 0xFFFFFFFF;
            if (health.get()) {
                float hp = e.getHealth() + e.getAbsorptionAmount();
                text += String.format(Locale.ROOT, " %.1f", hp);
                float f = Mth.clamp(e.getHealth() / Math.max(1.0f, e.getMaxHealth()), 0f, 1f);
                int r = (int) (255 * (1f - f));
                int gr = (int) (255 * f);
                hpColor = 0xFF000000 | (r << 16) | (gr << 8);
            }
            if (distance.get() && !isSelf) {
                text += String.format(Locale.ROOT, " %.0fm", dist);
            }

            int w = mc.font.width(text);
            int px = (int) Math.round(s[0]) - w / 2;
            int py = (int) Math.round(s[1]) - mc.font.lineHeight;
            g.fill(px - 2, py - 1, px + w + 2, py + mc.font.lineHeight, bgAlpha.getInt() << 24);
            g.drawString(mc.font, text, px, py, health.get() ? hpColor : textColor, true);
        }
    }
}
