package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.util.Targets;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

public class TriggerBot extends Module {
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", false);
    private final BoolSetting cooldown = bool("Wait Cooldown", true);

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null) {
            return;
        }
        HitResult hit = mc.hitResult;
        if (!(hit instanceof EntityHitResult)) {
            return;
        }
        Entity target = ((EntityHitResult) hit).getEntity();
        if (!Targets.valid(p, target, players.get(), mobs.get())) {
            return;
        }
        if (cooldown.get() && p.getAttackStrengthScale(0.0f) < 0.95f) {
            return;
        }
        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
