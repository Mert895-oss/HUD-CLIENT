package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Finds blocks in loaded chunks (a few chunks per tick), shows them as boxes + tracers
 * and writes new finds with coordinates to the chat.
 */
public abstract class BlockFinder extends Module {
    protected final BoolSetting fill;
    protected final NumberSetting fillAlpha;
    protected final BoolSetting outline;
    protected final NumberSetting width;
    protected final BoolSetting tracers;
    protected final BoolSetting chat;
    protected final NumberSetting range;
    protected final NumberSetting limit;
    protected final ColorSetting color;

    private final Map<Long, List<BlockPos>> found = new HashMap<>();
    private final Set<Long> alerted = new HashSet<>();
    private final ArrayDeque<int[]> queue = new ArrayDeque<>();
    private int timer;

    protected BlockFinder(String name, Category category, int r, int g, int b) {
        super(name, category);
        fill = bool("Fill", true);
        fillAlpha = num("Fill Alpha", 50, 0, 255, 1);
        outline = bool("Outline", true);
        width = num("Line Width", 0.03, 0.005, 0.15, 0.005);
        tracers = bool("Tracers", true);
        chat = bool("Chat Coords", true);
        range = num("Range", 64, 8, 192, 8);
        limit = num("Max Boxes", 300, 20, 2000, 20);
        color = color("Color", r, g, b);
    }

    protected abstract boolean isTarget(BlockState state);

    protected boolean accept(ClientLevel level, BlockPos pos) {
        return true;
    }

    /** Return false to pause scanning (for example outside the Nether). */
    protected boolean active() {
        return true;
    }

    protected void beforeScan() {
    }

    protected String label(BlockState state) {
        return BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
    }

    protected void rescan() {
        found.clear();
        alerted.clear();
        queue.clear();
        timer = 0;
    }

    private static long key(int cx, int cz) {
        return ((long) cx & 0xFFFFFFFFL) | (((long) cz & 0xFFFFFFFFL) << 32);
    }

    @Override
    public void onEnable() {
        rescan();
    }

    @Override
    public void onDisable() {
        rescan();
    }

    @Override
    public void onTick() {
        ClientLevel level = mc.level;
        LocalPlayer p = mc.player;
        if (level == null || p == null) {
            return;
        }
        if (!active()) {
            if (!found.isEmpty()) {
                rescan();
            }
            return;
        }
        int pcx = p.getBlockX() >> 4;
        int pcz = p.getBlockZ() >> 4;
        int r = (int) Math.ceil(range.getD() / 16.0) + 1;

        if (timer-- <= 0) {
            timer = 60;
            beforeScan();
            queue.clear();
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    queue.add(new int[]{pcx + dx, pcz + dz});
                }
            }
            Iterator<Long> it = found.keySet().iterator();
            while (it.hasNext()) {
                long k = it.next();
                int cx = (int) k;
                int cz = (int) (k >> 32);
                if (Math.abs(cx - pcx) > r + 2 || Math.abs(cz - pcz) > r + 2) {
                    it.remove();
                }
            }
        }

        int budget = 6;
        while (budget-- > 0 && !queue.isEmpty()) {
            int[] c = queue.poll();
            scan(level, c[0], c[1]);
        }
    }

    private void scan(ClientLevel level, int cx, int cz) {
        long k = key(cx, cz);
        ChunkAccess access = level.getChunk(cx, cz, ChunkStatus.FULL, false);
        if (!(access instanceof LevelChunk chunk)) {
            found.remove(k);
            return;
        }
        int minY = level.dimensionType().minY();
        LevelChunkSection[] sections = chunk.getSections();
        List<BlockPos> list = null;
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection s = sections[i];
            if (s == null || s.hasOnlyAir() || !s.maybeHas(this::isTarget)) {
                continue;
            }
            int baseY = minY + i * 16;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState st = s.getBlockState(x, y, z);
                        if (!isTarget(st)) {
                            continue;
                        }
                        BlockPos pos = new BlockPos(cx * 16 + x, baseY + y, cz * 16 + z);
                        if (!accept(level, pos)) {
                            continue;
                        }
                        if (list == null) {
                            list = new ArrayList<>();
                        }
                        if (list.size() < 256) {
                            list.add(pos);
                        }
                    }
                }
            }
        }
        if (list == null) {
            found.remove(k);
        } else {
            found.put(k, list);
            alert(level, list);
        }
    }

    private void alert(ClientLevel level, List<BlockPos> list) {
        int fresh = 0;
        int sent = 0;
        for (BlockPos pos : list) {
            if (!alerted.add(pos.asLong())) {
                continue;
            }
            fresh++;
            if (chat.get() && mc.player != null && sent < 3) {
                sent++;
                String msg = String.format(Locale.ROOT, "[HUD] %s: %d %d %d",
                        label(level.getBlockState(pos)), pos.getX(), pos.getY(), pos.getZ());
                mc.player.displayClientMessage(Component.literal(msg), false);
            }
        }
        if (chat.get() && mc.player != null && fresh > sent) {
            mc.player.displayClientMessage(Component.literal("[HUD] (+" + (fresh - sent) + " more nearby)"), false);
        }
    }

    @Override
    public void onRender3D() {
        LocalPlayer p = mc.player;
        if (p == null || found.isEmpty()) {
            return;
        }
        double range2 = range.getD() * range.getD();
        int lineColor = color.argb(230);
        int fillColor = color.argb(fillAlpha.getInt());
        Vec3 from = tracers.get() ? Render3D.tracerOrigin() : null;
        int max = limit.getInt();
        int count = 0;
        for (List<BlockPos> list : found.values()) {
            for (BlockPos pos : list) {
                if (count >= max) {
                    return;
                }
                if (p.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > range2) {
                    continue;
                }
                count++;
                AABB box = new AABB(pos).inflate(0.002);
                if (fill.get()) {
                    Render3D.box(box, fillColor);
                }
                if (outline.get()) {
                    Render3D.outline(box, width.getD(), lineColor);
                }
                if (from != null) {
                    Render3D.line(from, box.getCenter(), width.getD(), lineColor);
                }
            }
        }
    }
}
