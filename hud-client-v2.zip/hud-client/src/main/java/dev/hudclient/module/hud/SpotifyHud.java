package dev.hudclient.module.hud;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.hudclient.HudClient;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphics;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Locale;

/**
 * Shows the song you are playing on Spotify.
 * 1) config/hud-spotify.json with client_id, client_secret and refresh_token: works on every device (uses the Spotify Web API).
 * 2) Without that file, on Windows it reads the title of the Spotify window.
 */
public class SpotifyHud extends Module {
    private final ModeSetting position = mode("Position", "Bottom Right", "Top Center", "Bottom Right", "Bottom Center", "Bottom Left");
    private final BoolSetting progressBar = bool("Progress Bar", true);
    private final NumberSetting bgAlpha = num("Background Alpha", 150, 0, 255, 1);
    private final ColorSetting color = color("Color", 30, 215, 96);

    private volatile String title = "";
    private volatile String artist = "";
    private volatile String status = "Baglaniyor...";
    private volatile long progressMs;
    private volatile long durationMs;
    private volatile boolean playing;
    private volatile long polledAt;
    private volatile boolean running;

    public SpotifyHud() {
        super("Spotify", Category.HUD);
    }

    @Override
    public void onEnable() {
        if (running) {
            return;
        }
        running = true;
        Thread t = new Thread(this::loop, "hud-spotify");
        t.setDaemon(true);
        t.start();
    }

    @Override
    public void onDisable() {
        running = false;
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void onRenderHud(GuiGraphics g) {
        String t = title;
        String a = artist;
        boolean hasSong = !t.isEmpty();
        String line1 = hasSong ? t : status;
        String line2 = hasSong ? a : "";

        int w = Math.max(mc.font.width(line1), mc.font.width(line2)) + 14;
        w = Math.max(w, 90);
        boolean bar = progressBar.get() && hasSong && durationMs > 0;
        int h = 9 + mc.font.lineHeight + (line2.isEmpty() ? 0 : mc.font.lineHeight + 1) + (bar ? 6 : 0);

        int sw = g.guiWidth();
        int sh = g.guiHeight();
        int x;
        int y;
        String pos = position.get();
        if (pos.equals("Top Center")) {
            x = (sw - w) / 2;
            y = 6;
        } else if (pos.equals("Bottom Center")) {
            x = (sw - w) / 2;
            y = sh - h - 40;
        } else if (pos.equals("Bottom Left")) {
            x = 6;
            y = sh - h - 40;
        } else {
            x = sw - w - 6;
            y = sh - h - 30;
        }

        int accent = 0xFF000000 | color.rgb();
        g.fill(x + 1, y, x + w - 1, y + h, bgAlpha.getInt() << 24);
        g.fill(x, y + 1, x + w, y + h - 1, bgAlpha.getInt() << 24);
        g.fill(x, y + 1, x + 2, y + h - 1, accent);

        int ty = y + 4;
        g.drawString(mc.font, line1, x + 7, ty, 0xFFFFFFFF, true);
        ty += mc.font.lineHeight + 1;
        if (!line2.isEmpty()) {
            g.drawString(mc.font, line2, x + 7, ty, 0xFFAAAAAA, true);
            ty += mc.font.lineHeight + 1;
        }
        if (bar) {
            long p = progressMs;
            if (playing) {
                p += System.currentTimeMillis() - polledAt;
            }
            double f = Math.max(0.0, Math.min(1.0, p / (double) durationMs));
            int bx = x + 7;
            int bw = w - 14;
            g.fill(bx, ty + 1, bx + bw, ty + 3, 0xFF333333);
            g.fill(bx, ty + 1, bx + (int) (bw * f), ty + 3, accent);
        }
    }

    // ------------------------------------------------------------------ polling thread

    private void loop() {
        while (running) {
            try {
                Path file = FabricLoader.getInstance().getConfigDir().resolve("hud-spotify.json");
                if (Files.exists(file)) {
                    pollApi(file);
                } else if (System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win")) {
                    pollWindowTitle();
                } else {
                    status = "Spotify: config/hud-spotify.json gerekli";
                    title = "";
                    writeTemplate(file);
                }
            } catch (Exception e) {
                status = "Spotify: hata";
                HudClient.LOGGER.debug("Spotify poll failed", e);
            }
            try {
                Thread.sleep(3000L);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    private void writeTemplate(Path file) {
        // only create the template once so the user can fill it in
        try {
            Path tpl = file.resolveSibling("hud-spotify.example.json");
            if (!Files.exists(tpl)) {
                Files.writeString(tpl, "{\n  \"client_id\": \"\",\n  \"client_secret\": \"\",\n  \"refresh_token\": \"\"\n}\n");
            }
        } catch (Exception ignored) {
        }
    }

    private void pollWindowTitle() throws Exception {
        Process p = new ProcessBuilder("powershell", "-NoProfile", "-Command",
                "(Get-Process Spotify -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle } | Select-Object -First 1).MainWindowTitle")
                .redirectErrorStream(true).start();
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        p.waitFor();
        int dash = out.indexOf(" - ");
        if (dash > 0) {
            artist = out.substring(0, dash);
            title = out.substring(dash + 3);
            playing = true;
            durationMs = 0;
            status = "";
        } else {
            title = "";
            artist = "";
            status = out.isEmpty() ? "Spotify kapali" : "Spotify duraklatildi";
        }
    }

    private String accessToken;
    private long tokenExpiry;

    private void pollApi(Path file) throws Exception {
        JsonObject cfg = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
        String id = str(cfg, "client_id");
        String secret = str(cfg, "client_secret");
        String refresh = str(cfg, "refresh_token");
        if (id.isEmpty() || secret.isEmpty() || refresh.isEmpty()) {
            status = "Spotify: hud-spotify.json eksik";
            title = "";
            return;
        }
        if (accessToken == null || System.currentTimeMillis() > tokenExpiry) {
            HttpURLConnection c = (HttpURLConnection) new URL("https://accounts.spotify.com/api/token").openConnection();
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(5000);
            c.setReadTimeout(5000);
            String basic = Base64.getEncoder().encodeToString((id + ":" + secret).getBytes(StandardCharsets.UTF_8));
            c.setRequestProperty("Authorization", "Basic " + basic);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            String body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, StandardCharsets.UTF_8);
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
            if (c.getResponseCode() != 200) {
                status = "Spotify: giris hatasi (" + c.getResponseCode() + ")";
                title = "";
                accessToken = null;
                return;
            }
            JsonObject tok = JsonParser.parseString(readAll(c.getInputStream())).getAsJsonObject();
            accessToken = tok.get("access_token").getAsString();
            long expires = tok.has("expires_in") ? tok.get("expires_in").getAsLong() : 3600L;
            tokenExpiry = System.currentTimeMillis() + (expires - 60L) * 1000L;
        }

        HttpURLConnection c = (HttpURLConnection) new URL("https://api.spotify.com/v1/me/player/currently-playing?additional_types=track,episode").openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(5000);
        c.setRequestProperty("Authorization", "Bearer " + accessToken);
        int code = c.getResponseCode();
        if (code == 204) {
            title = "";
            artist = "";
            status = "Spotify: calan sarki yok";
            return;
        }
        if (code != 200) {
            status = "Spotify: hata (" + code + ")";
            title = "";
            if (code == 401) {
                accessToken = null;
            }
            return;
        }
        JsonObject root = JsonParser.parseString(readAll(c.getInputStream())).getAsJsonObject();
        JsonElement itemEl = root.get("item");
        if (itemEl == null || !itemEl.isJsonObject()) {
            title = "";
            status = "Spotify: calan sarki yok";
            return;
        }
        JsonObject item = itemEl.getAsJsonObject();
        String name = str(item, "name");
        String by = "";
        if (item.has("artists") && item.get("artists").isJsonArray()) {
            JsonArray arr = item.getAsJsonArray("artists");
            StringBuilder sb = new StringBuilder();
            for (JsonElement e : arr) {
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append(str(e.getAsJsonObject(), "name"));
            }
            by = sb.toString();
        } else if (item.has("show") && item.get("show").isJsonObject()) {
            by = str(item.getAsJsonObject("show"), "name");
        }
        progressMs = root.has("progress_ms") && !root.get("progress_ms").isJsonNull() ? root.get("progress_ms").getAsLong() : 0L;
        durationMs = item.has("duration_ms") ? item.get("duration_ms").getAsLong() : 0L;
        playing = root.has("is_playing") && root.get("is_playing").getAsBoolean();
        polledAt = System.currentTimeMillis();
        artist = by;
        title = name;
        status = "";
    }

    private static String str(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e == null || e.isJsonNull() ? "" : e.getAsString();
    }

    private static String readAll(InputStream in) throws Exception {
        try (in) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
