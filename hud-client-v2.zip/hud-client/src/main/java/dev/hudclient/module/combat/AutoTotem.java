package dev.hudclient.module.combat;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

public class AutoTotem extends Module {
    private final NumberSetting delay = num("Delay (ticks)", 2, 0, 10, 1);
    private int wait;

    public AutoTotem() {
        super("AutoTotem", Category.COMBAT);
    }

    @Override
    public void onTick() {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) {
            return;
        }
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            wait = delay.getInt();
            return;
        }
        if (wait > 0) {
            wait--;
            return;
        }
        int slot = -1;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                slot = i;
                break;
            }
        }
        if (slot < 0) {
            return;
        }
        // inventory menu ids: hotbar 36..44, main 9..35, offhand 45
        int menuSlot = slot < 9 ? slot + 36 : slot;
        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, menuSlot, 40, ClickType.SWAP, p);
        wait = delay.getInt();
    }
}
