package dev.hudclient.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.ArrayList;
import java.util.List;

/** A list of block ids (like "minecraft:diamond_ore"). Edited with chat commands, saved in the config. */
public class BlockListSetting extends Setting<List<String>> {
    public BlockListSetting(String name) {
        super(name, new ArrayList<>());
    }

    public boolean add(String id) {
        if (value.contains(id)) {
            return false;
        }
        value.add(id);
        return true;
    }

    public boolean remove(String id) {
        return value.remove(id);
    }

    public void clear() {
        value.clear();
    }

    @Override
    public JsonElement save() {
        JsonArray a = new JsonArray();
        for (String s : value) {
            a.add(new JsonPrimitive(s));
        }
        return a;
    }

    @Override
    public void load(JsonElement element) {
        if (element != null && element.isJsonArray()) {
            value.clear();
            for (JsonElement e : element.getAsJsonArray()) {
                if (e.isJsonPrimitive()) {
                    value.add(e.getAsString());
                }
            }
        }
    }

    @Override
    public String toString() {
        return value.size() + " blok";
    }
}
