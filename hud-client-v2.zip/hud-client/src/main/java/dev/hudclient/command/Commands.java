package dev.hudclient.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.module.misc.NameProtect;
import dev.hudclient.module.misc.SkinStealer;
import dev.hudclient.module.render.BlockEsp;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

/**
 * Chat commands (typed in the normal chat box, they never reach the server):
 *   /blockesp add|remove <block>, /blockesp list, /blockesp clear
 *   /nameprotect <name>, /nameprotect off
 *   /skinsteal <player>, /skinsteal reset
 */
public final class Commands {
    private Commands() {
    }

    private static int say(CommandContext<FabricClientCommandSource> c, String msg) {
        c.getSource().sendFeedback(Component.literal("[HUD] " + msg));
        return 1;
    }

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("blockesp")
                .then(ClientCommandManager.literal("add")
                        .then(ClientCommandManager.argument("block", StringArgumentType.word())
                                .executes(c -> {
                                    BlockEsp m = ModuleManager.get(BlockEsp.class);
                                    return say(c, m.addBlock(StringArgumentType.getString(c, "block")));
                                })))
                .then(ClientCommandManager.literal("remove")
                        .then(ClientCommandManager.argument("block", StringArgumentType.word())
                                .executes(c -> {
                                    BlockEsp m = ModuleManager.get(BlockEsp.class);
                                    return say(c, m.removeBlock(StringArgumentType.getString(c, "block")));
                                })))
                .then(ClientCommandManager.literal("list")
                        .executes(c -> say(c, ModuleManager.get(BlockEsp.class).listBlocks())))
                .then(ClientCommandManager.literal("clear")
                        .executes(c -> say(c, ModuleManager.get(BlockEsp.class).clearBlocks()))));

        d.register(ClientCommandManager.literal("nameprotect")
                .then(ClientCommandManager.literal("off")
                        .executes(c -> {
                            ModuleManager.get(NameProtect.class).setEnabled(false);
                            return say(c, "NameProtect kapali");
                        }))
                .then(ClientCommandManager.argument("name", StringArgumentType.word())
                        .executes(c -> {
                            NameProtect m = ModuleManager.get(NameProtect.class);
                            String n = StringArgumentType.getString(c, "name");
                            m.fakeName.set(n);
                            m.setEnabled(true);
                            return say(c, "Yeni isim: " + n);
                        })));

        d.register(ClientCommandManager.literal("skinsteal")
                .then(ClientCommandManager.literal("reset")
                        .executes(c -> {
                            ModuleManager.get(SkinStealer.class).setEnabled(false);
                            return say(c, "Skin eski haline dondu");
                        }))
                .then(ClientCommandManager.argument("player", StringArgumentType.word())
                        .executes(c -> {
                            SkinStealer m = ModuleManager.get(SkinStealer.class);
                            boolean ok = m.stealFrom(StringArgumentType.getString(c, "player"));
                            return say(c, ok ? "Skin kopyalandi" : "Oyuncu bulunamadi (yakininda olmali)");
                        })));
    }
}
