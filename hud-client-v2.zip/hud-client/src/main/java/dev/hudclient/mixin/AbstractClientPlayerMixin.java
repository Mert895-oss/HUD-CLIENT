package dev.hudclient.mixin;

import dev.hudclient.module.misc.SkinStealer;
import net.minecraft.client.player.AbstractClientPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** SkinStealer: the local player uses the copied skin (only you see it). */
@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void hud$getSkin(CallbackInfoReturnable cir) {
        Object stolen = SkinStealer.stolenFor(this);
        if (stolen != null) {
            cir.setReturnValue(stolen);
        }
    }
}
