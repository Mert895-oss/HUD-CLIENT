package dev.hudclient.mixin;

import dev.hudclient.util.CameraControl;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While Freecam/Freelook is on, mouse movement turns the camera instead of the player. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true)
    private void hud$turn(double yRot, double xRot, CallbackInfo ci) {
        if (!CameraControl.active()) {
            return;
        }
        if ((Object) this != Minecraft.getInstance().player) {
            return;
        }
        CameraControl.yaw += (float) yRot * 0.15f;
        CameraControl.pitch = Mth.clamp(CameraControl.pitch + (float) xRot * 0.15f, -90.0f, 90.0f);
        ci.cancel();
    }
}
