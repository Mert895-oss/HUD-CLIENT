HUD v2  -  Minecraft 1.21.11 / Fabric (Mojang mappings)

Derleme: GitHub Actions (build.yml) ile. Jar: hud-client-2.0.0.jar
Mod klasorune at: Fabric Loader 0.18.1+ ve Fabric API gerekir.

OYUNDA
  Sag Shift = menu
  Sol tik = modul ac/kapat | Sag tik = ayarlar | Orta tik = tus ata (ESC = bagi sil)
  Ayarlar .minecraft/config klasorune kaydedilir.

KOMUTLAR (sohbet kutusuna yaz, sunucuya gitmez)
  /blockesp add <blok>      ornek: /blockesp add ancient_debris
  /blockesp remove <blok> | /blockesp list | /blockesp clear
  /nameprotect <isim>       sohbette kendi adini bu isimle degistirir
  /nameprotect off
  /skinsteal <oyuncu>       yakindaki oyuncunun skinini kopyalar (sadece sen gorursun)
  /skinsteal reset

FREECAM: W A S D, Bosluk (yukari), Sol Shift (asagi)
FREELOOK: fareyle etrafa bak, karakter donmez, kamera duvarlardan gecer

SPOTIFY
  Windows'ta ek ayar olmadan Spotify penceresinden sarkiyi okur.
  Telefon/diger sistemler icin config/hud-spotify.json dosyasi gerekir:
  {"client_id":"...","client_secret":"...","refresh_token":"..."}
  (Spotify Developer'da uygulama olusturup refresh token almak gerekir.)

Gradle "surum bulunamadi" derse gradle.properties icindeki fabric_api_version'u
fabricmc.net/develop adresindeki guncel surumle degistir.
