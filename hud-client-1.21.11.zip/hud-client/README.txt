HUD client v1  -  Minecraft 1.21.11 / Fabric (Mojang mappings)

Gerekenler: JDK 21, IntelliJ IDEA (veya terminalde gradle).
ONEMLI: gradle-wrapper.jar bu pakette yok. Iki yol:
  A) fabricmc.net/develop/template ile 1.21.11 bos proje indir, icindeki
     gradlew, gradlew.bat ve gradle/wrapper/ klasorunu bu projenin icine kopyala.
  B) Bilgisayarinda Gradle varsa: gradle wrapper --gradle-version 9.2.0

Derle:  ./gradlew build     ->  build/libs/hud-client-1.0.0.jar
Jar'i .minecraft/mods icine at (Fabric Loader 0.18.1+ ve Fabric API gerekir).

Oyunda: Sag Shift = menu
  Sol tik = modul ac/kapat | Sag tik = ayarlar (renk, boyut vs.) | Orta tik = tus ata
Ayarlar .minecraft/config/hud-client.json icine kaydedilir.

Gradle "surum bulunamadi" derse gradle.properties icindeki fabric_api_version'u
fabricmc.net/develop adresindeki guncel surumle degistir.
