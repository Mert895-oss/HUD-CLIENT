package dev.hudclient.module.render;

import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.render.Render3D;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ColorSetting;
import dev.hudclient.setting.NumberSetting;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class PlayerEsp extends Module {
    private final ColorSetting color = color("Color", 255, 60, 60);
    private final BoolSetting fill = bool("Fill", true);
    private final NumberSetting fillAlpha = num("Fill Alpha", 45, 0, 255, 1);
    private final BoolSetting outline = bool("Outline", true);
    private final NumberSetting width = num("Line Width", 0.03, 0.005, 0.15, 0.005);
    private final BoolSetting tracers = bool("Tracers", false);
    private final BoolSetting invisible = bool("Show Invisible", true);
    private final NumberSetting range = num("Range", 128, 16, 512, 8);

    public PlayerEsp() {
        super("PlayerESP", Category.RENDER);
    }

    @Override
    public void onRender3D() {
        ClientLevel level = mc.level;
        LocalPlayer self = mc.player;
        if (level == null || self == null) {
            return;
        }
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        double range2 = range.getD() * range.getD();
        int lineColor = color.argb(230);
        int fillColor = color.argb(fillAlpha.getInt());
        Vec3 eye = self.getEyePosition(pt);
        Vec3 look = self.getViewVector(pt);

        for (AbstractClientPlayer e : level.players()) {
            if (e == self || e.isSpectator()) {
                continue;
            }
            if (!invisible.get() && e.isInvisible()) {
                continue;
            }
            if (self.distanceToSqr(e) > range2) {
                continue;
            }
            double ox = Mth.lerp(pt, e.xo, e.getX()) - e.getX();
            double oy = Mth.lerp(pt, e.yo, e.getY()) - e.getY();
            double oz = Mth.lerp(pt, e.zo, e.getZ()) - e.getZ();
            AABB box = e.getBoundingBox().move(ox, oy, oz).inflate(0.05);

            if (fill.get()) {
                Render3D.box(box, fillColor);
            }
            if (outline.get()) {
                Render3D.outline(box, width.getD(), lineColor);
            }
            if (tracers.get()) {
                Vec3 from = eye.add(look.scale(0.6));
                Render3D.line(from, box.getCenter(), width.getD(), lineColor);
            }
        }
    }
}
