package dev.hudclient.module;

import dev.hudclient.HudClient;
import dev.hudclient.gui.ClickGuiScreen;
import dev.hudclient.module.chunk.PlayerChunk;
import dev.hudclient.module.chunk.SpawnerChunkFinder;
import dev.hudclient.module.chunk.SusChunkFinder;
import dev.hudclient.module.combat.AimAssist;
import dev.hudclient.module.combat.AutoTotem;
import dev.hudclient.module.combat.KillAura;
import dev.hudclient.module.combat.Sprint;
import dev.hudclient.module.combat.TriggerBot;
import dev.hudclient.module.hud.HudModule;
import dev.hudclient.module.render.PearlPredict;
import dev.hudclient.module.render.PlayerEsp;
import dev.hudclient.module.render.StorageEsp;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean guiKeyWasDown;

    private ModuleManager() {
    }

    public static void init() {
        // Combat
        MODULES.add(new KillAura());
        MODULES.add(new TriggerBot());
        MODULES.add(new AimAssist());
        MODULES.add(new AutoTotem());
        MODULES.add(new Sprint());
        // Render
        MODULES.add(new PlayerEsp());
        MODULES.add(new StorageEsp());
        MODULES.add(new PearlPredict());
        // Chunks
        MODULES.add(new PlayerChunk());
        MODULES.add(new SusChunkFinder());
        MODULES.add(new SpawnerChunkFinder());
        // HUD
        MODULES.add(new HudModule());
    }

    public static List<Module> all() {
        return Collections.unmodifiableList(MODULES);
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) {
            if (type.isInstance(m)) {
                return (T) m;
            }
        }
        return null;
    }

    /** Accent color (RGB) taken from the HUD module color. */
    public static int accent() {
        HudModule hud = get(HudModule.class);
        return hud == null ? 0x55FFFF : hud.color.rgb();
    }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) {
            return;
        }
        handleKeys(mc);
        for (Module m : MODULES) {
            if (!m.isEnabled()) {
                continue;
            }
            try {
                m.onTick();
            } catch (RuntimeException e) {
                HudClient.LOGGER.error("Error in {} tick", m.getName(), e);
            }
        }
    }

    public static void render3D() {
        for (Module m : MODULES) {
            if (!m.isEnabled()) {
                continue;
            }
            try {
                m.onRender3D();
            } catch (RuntimeException e) {
                HudClient.LOGGER.error("Error in {} render", m.getName(), e);
            }
        }
    }

    public static void renderHud(GuiGraphics graphics) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) {
            return;
        }
        for (Module m : MODULES) {
            if (!m.isEnabled()) {
                continue;
            }
            try {
                m.onRenderHud(graphics);
            } catch (RuntimeException e) {
                HudClient.LOGGER.error("Error in {} hud", m.getName(), e);
            }
        }
    }

    private static void handleKeys(Minecraft mc) {
        if (mc.screen != null) {
            // keep edge state fresh so a held key does not trigger when the screen closes
            return;
        }
        long window = GLFW.glfwGetCurrentContext();

        boolean guiDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (guiDown && !guiKeyWasDown) {
            mc.setScreen(new ClickGuiScreen());
        }
        guiKeyWasDown = guiDown;

        for (Module m : MODULES) {
            int key = m.getKey();
            if (key < 0) {
                continue;
            }
            boolean down = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
            if (down && !m.keyWasDown) {
                m.toggle();
            }
            m.keyWasDown = down;
        }
    }
}
