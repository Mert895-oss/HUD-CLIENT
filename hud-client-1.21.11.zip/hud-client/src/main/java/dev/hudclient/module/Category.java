package dev.hudclient.module;

public enum Category {
    COMBAT("Combat"),
    RENDER("Render"),
    CHUNKS("Chunks"),
    HUD("HUD");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
