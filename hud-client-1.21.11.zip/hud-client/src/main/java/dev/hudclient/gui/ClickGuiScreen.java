package dev.hudclient.gui;

import dev.hudclient.config.Config;
import dev.hudclient.module.Category;
import dev.hudclient.module.Module;
import dev.hudclient.module.ModuleManager;
import dev.hudclient.setting.BoolSetting;
import dev.hudclient.setting.ModeSetting;
import dev.hudclient.setting.NumberSetting;
import dev.hudclient.setting.Setting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Click GUI.
 * Left click  = module on/off
 * Right click = open that module's settings (right click again / click outside = close)
 * Middle click = bind a key (press a key; ESC clears the bind)
 */
public class ClickGuiScreen extends Screen {
    private static final int PW = 104;      // category panel width
    private static final int ROW = 13;      // row height
    private static final int HEAD = 16;     // header height
    private static final int TOP = 24;
    private static final int GAP = 6;
    private static final int COLW = 172;    // settings column width

    private Module open;
    private Module binding;
    private NumberSetting dragging;
    private int dragX0;
    private int dragX1;

    // settings panel layout (computed by layout())
    private int px;
    private int py;
    private int pw;
    private int ph;
    private int rowsPerCol;

    public ClickGuiScreen() {
        super(Component.literal("HUD"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        Config.save();
        super.onClose();
    }

    // ------------------------------------------------------------------ helpers

    private static List<Module> modulesOf(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (m.category == c) {
                out.add(m);
            }
        }
        return out;
    }

    private int catX(int i) {
        int n = Category.values().length;
        int total = n * PW + (n - 1) * GAP;
        return (this.width - total) / 2 + i * (PW + GAP);
    }

    private static String keyName(int key) {
        if (key < 0) {
            return "";
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) return "RCTRL";
        if (key == GLFW.GLFW_KEY_LEFT_CONTROL) return "LCTRL";
        if (key == GLFW.GLFW_KEY_RIGHT_ALT) return "RALT";
        if (key == GLFW.GLFW_KEY_LEFT_ALT) return "LALT";
        if (key == GLFW.GLFW_KEY_SPACE) return "SPACE";
        if (key == GLFW.GLFW_KEY_TAB) return "TAB";
        String n = GLFW.glfwGetKeyName(key, 0);
        return n != null ? n.toUpperCase(Locale.ROOT) : "K" + key;
    }

    private void layout() {
        if (open == null) {
            return;
        }
        int rows = Math.max(1, open.getSettings().size());
        int maxRows = Math.max(4, (this.height - 50 - HEAD) / ROW);
        int cols = (rows + maxRows - 1) / maxRows;
        rowsPerCol = (rows + cols - 1) / cols;
        pw = cols * COLW + 8;
        ph = HEAD + rowsPerCol * ROW + 8;
        px = (this.width - pw) / 2;
        py = Math.max(8, (this.height - ph) / 2);
    }

    private int rowX(int i) {
        return px + 4 + (i / rowsPerCol) * COLW;
    }

    private int rowY(int i) {
        return py + HEAD + 2 + (i % rowsPerCol) * ROW;
    }

    private int rowW() {
        return COLW - 6;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);

        pollBindKey();

        int accent = 0xFF000000 | ModuleManager.accent();
        Category[] cats = Category.values();

        g.drawString(this.font, "Sol tik: ac/kapat | Sag tik: ayarlar | Orta tik: tus ata", 6, 6, 0xFFAAAAAA, true);

        for (int i = 0; i < cats.length; i++) {
            int x = catX(i);
            int y = TOP;
            List<Module> mods = modulesOf(cats[i]);
            int h = HEAD + mods.size() * ROW + 2;

            g.fill(x, y, x + PW, y + h, 0xDD101018);
            g.fill(x, y, x + PW, y + HEAD, 0xFF1C1C2A);
            g.fill(x, y + HEAD - 1, x + PW, y + HEAD, accent);
            g.drawString(this.font, cats[i].label, x + 4, y + 4, 0xFFFFFFFF, true);

            int ry = y + HEAD;
            for (Module m : mods) {
                boolean hover = open == null && mouseX >= x && mouseX < x + PW && mouseY >= ry && mouseY < ry + ROW;
                if (hover) {
                    g.fill(x, ry, x + PW, ry + ROW, 0x30FFFFFF);
                }
                if (m.isEnabled()) {
                    g.fill(x, ry, x + 2, ry + ROW, accent);
                }
                g.drawString(this.font, m.getName(), x + 6, ry + 3, m.isEnabled() ? accent : 0xFFAAAAAA, true);

                String tag;
                if (binding == m) {
                    tag = "...";
                } else if (m.getKey() >= 0) {
                    tag = "[" + keyName(m.getKey()) + "]";
                } else {
                    tag = m.getSettings().isEmpty() ? "" : ">";
                }
                if (!tag.isEmpty()) {
                    g.drawString(this.font, tag, x + PW - 4 - this.font.width(tag), ry + 3, 0xFF777777, false);
                }
                ry += ROW;
            }
        }

        if (open != null) {
            drawSettings(g, mouseX, mouseY, accent);
        }
    }

    private void drawSettings(GuiGraphics g, int mouseX, int mouseY, int accent) {
        layout();
        g.fill(0, 0, this.width, this.height, 0x80000000);
        g.fill(px, py, px + pw, py + ph, 0xF0101018);
        g.fill(px, py, px + pw, py + HEAD, 0xFF1C1C2A);
        g.fill(px, py + HEAD - 1, px + pw, py + HEAD, accent);
        g.drawString(this.font, open.getName() + " - ayarlar", px + 4, py + 4, 0xFFFFFFFF, true);

        List<Setting<?>> list = open.getSettings();
        for (int i = 0; i < list.size(); i++) {
            Setting<?> s = list.get(i);
            int x = rowX(i);
            int y = rowY(i);
            int w = rowW();
            g.fill(x, y, x + w, y + ROW - 1, 0x50000000);

            if (s instanceof BoolSetting b) {
                g.drawString(this.font, b.name, x + 4, y + 3, 0xFFFFFFFF, false);
                String t = b.get() ? "ON" : "OFF";
                g.drawString(this.font, t, x + w - 4 - this.font.width(t), y + 3, b.get() ? accent : 0xFF888888, false);
            } else if (s instanceof NumberSetting n) {
                int fillW = (int) Math.round(n.fraction() * w);
                g.fill(x, y, x + fillW, y + ROW - 1, (accent & 0x00FFFFFF) | 0x60000000);
                g.drawString(this.font, n.name + ": " + n.display(), x + 4, y + 3, 0xFFFFFFFF, false);
                if (n.preview != null) {
                    g.fill(x + w - 12, y + 2, x + w - 3, y + ROW - 3, 0xFF000000 | n.preview.rgb());
                }
            } else if (s instanceof ModeSetting m) {
                g.drawString(this.font, m.name, x + 4, y + 3, 0xFFFFFFFF, false);
                String t = "< " + m.get() + " >";
                g.drawString(this.font, t, x + w - 4 - this.font.width(t), y + 3, accent, false);
            } else {
                g.drawString(this.font, s.name, x + 4, y + 3, 0xFFFFFFFF, false);
            }
        }
    }

    // ------------------------------------------------------------------ key binding (polls GLFW like ModuleManager does)

    private void pollBindKey() {
        if (binding == null) {
            return;
        }
        long window = GLFW.glfwGetCurrentContext();
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS) {
                binding.setKey(k == GLFW.GLFW_KEY_ESCAPE ? -1 : k);
                binding = null;
                return;
            }
        }
    }

    // ------------------------------------------------------------------ mouse

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();
        int button = event.button();

        if (open != null) {
            layout();
            if (mx < px || mx > px + pw || my < py || my > py + ph) {
                open = null;
                Config.save();
                return true;
            }
            List<Setting<?>> list = open.getSettings();
            for (int i = 0; i < list.size(); i++) {
                int x = rowX(i);
                int y = rowY(i);
                int w = rowW();
                if (mx < x || mx >= x + w || my < y || my >= y + ROW) {
                    continue;
                }
                Setting<?> s = list.get(i);
                if (s instanceof BoolSetting b) {
                    b.toggle();
                } else if (s instanceof NumberSetting n) {
                    dragging = n;
                    dragX0 = x;
                    dragX1 = x + w;
                    n.setFromFraction((mx - x) / (double) w);
                } else if (s instanceof ModeSetting m) {
                    if (button == 1) {
                        m.prev();
                    } else {
                        m.next();
                    }
                }
                return true;
            }
            return true;
        }

        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int x = catX(i);
            int ry = TOP + HEAD;
            for (Module m : modulesOf(cats[i])) {
                if (mx >= x && mx < x + PW && my >= ry && my < ry + ROW) {
                    if (button == 0) {
                        m.toggle();
                        Config.save();
                    } else if (button == 1) {
                        if (!m.getSettings().isEmpty()) {
                            open = m;
                        }
                    } else if (button == 2) {
                        binding = m;
                    }
                    return true;
                }
                ry += ROW;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragXAmount, double dragYAmount) {
        if (dragging != null) {
            dragging.setFromFraction((event.x() - dragX0) / (double) (dragX1 - dragX0));
            return true;
        }
        return super.mouseDragged(event, dragXAmount, dragYAmount);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(event);
    }
}
